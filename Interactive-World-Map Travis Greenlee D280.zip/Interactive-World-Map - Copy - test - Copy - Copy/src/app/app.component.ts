import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [],
  schemas: [NO_ERRORS_SCHEMA]
})
export class AppComponent {
  title = 'Interactive-World-Map';
  plateUrl: string;
  country: any;
  capital: string;
  region: string;
  incomeLevel: string;
  longitude: string;
  latitude: string;

  constructor(private http: HttpClient) {
    this.plateUrl = '';
    this.country = '';
    this.capital = '';
    this.region = '';
    this.incomeLevel = '';
    this.longitude = '';
    this.latitude = '';
  }

  onCountryClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    const countryId = target.id; // Using id attribute to identify the country
    if (countryId) {
      this.fetchCountryData(countryId);
    }
  }

  fetchCountryData(countryId: string): void {
    this.plateUrl = `https://api.worldbank.org/v2/country/${countryId}?format=json`;
    this.http.get(this.plateUrl).subscribe(
      (response: any) => {
        console.log(response);
        const countryData = response[1][0];
        this.country = countryData.name;
        this.capital = countryData.capitalCity;
        this.region = countryData.region.value;
        this.incomeLevel = countryData.incomeLevel.value;
        this.longitude = countryData.longitude;
        this.latitude = countryData.latitude;
      },
      (error) => {
        console.error('Error fetching data', error);
      }
    );
  }
}